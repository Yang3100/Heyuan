//
//  cleanUpView.h
//  XinMinClub
//
//  Created by 杨科军 on 2017/1/20.
//  Copyright © 2017年 yangkejun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface cleanUpView : UIViewController

@end
