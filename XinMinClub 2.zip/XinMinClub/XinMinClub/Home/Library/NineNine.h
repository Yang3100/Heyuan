//
//  NineNine.h
//  
//
//  Created by 杨科军 on 2016/10/31.
//
//

#import <UIKit/UIKit.h>

@interface NineNine : UIView

- (id)initWithSize:(CGRect)frame Interior:(NSDictionary*)dict;

@property(nonatomic,copy) NSDictionary *dataDict;

@end
