//
//  ADViewController.h
//  XinMinClub
//
//  Created by yangkejun on 16/3/22.
//  Copyright © 2016年 yangkejun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ADViewController : UIViewController

@property (nonatomic, strong) NSString *ADTitle;
@property (nonatomic, strong) NSString *ADID;
@property (nonatomic, strong) NSString *ADImageUrl;
@property (nonatomic, strong) NSString *shopName;
@property (nonatomic, strong) NSString *shopID;
@property (nonatomic, strong) NSString *shopUrlString;

@end
