//
//  DetailsCell1.h
//  XinMinClub
//
//  Created by yangkejun on 16/3/29.
//  Copyright © 2016年 yangkejun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailsCell1 : UITableViewCell

@property(nonatomic, copy) NSString *details1Text;
@property(nonatomic, copy) NSString *details1Title;

@end
