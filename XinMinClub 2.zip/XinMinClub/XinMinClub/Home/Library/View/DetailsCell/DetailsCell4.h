//
//  DetailsCell4.h
//  XinMinClub
//
//  Created by 杨科军 on 2016/12/22.
//  Copyright © 2016年 yangkejun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailsCell4 : UITableViewCell

@property (nonatomic, strong) NSString *imageUrl;
@property (nonatomic, strong) NSString *libraryName;
    
@end
