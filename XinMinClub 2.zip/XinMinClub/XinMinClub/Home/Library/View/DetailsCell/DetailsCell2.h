//
//  DetailsCell2.h
//  XinMinClub
//
//  Created by 杨科军 on 16/4/20.
//  Copyright © 2016年 yangkejun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailsCell2 : UITableViewCell

@property(nonatomic, copy) NSString *details2Text;
@property (nonatomic, strong) NSString *details2Time;
@property(nonatomic, copy) NSString *details2Title;
@property (nonatomic, strong) NSString *detailsImageUrl;

@end
