//
//  SongCollectionCell.h
//  KJ5sing2
//
//  Created by yangkejun on 16/3/12.
//  Copyright © 2016年 yangkejun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LibraryCollectionCell : UICollectionViewCell

@property(nonatomic, copy) NSString *libraryImageUrl;
@property (nonatomic, strong) NSString *readtotal;

@end
