//
//  HomeNavController.h
//  XinMinClub
//
//  Created by 赵劲松 on 16/5/5.
//  Copyright © 2016年 yangkejun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomeNavController : UINavigationController

@end
