//
//  AuthorCell.m
//  XinMinClub
//
//  Created by 赵劲松 on 16/3/29.
//  Copyright © 2016年 yangkejun. All rights reserved.
//

#import "AuthorCell.h"

@implementation AuthorCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
