//
//  MyBookTableViewCell.h
//  XinMinClub
//
//  Created by Jason_zzzz on 16/3/21.
//  Copyright © 2016年 yangkejun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyBookTableViewCell : UITableViewCell

@property (nonatomic, strong) UILabel * label;
- (UIView *)footLine;

@end
