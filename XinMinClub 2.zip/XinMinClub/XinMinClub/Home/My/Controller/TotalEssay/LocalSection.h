//
//  LocalSection.h
//  XinMinClub
//
//  Created by 赵劲松 on 16/4/4.
//  Copyright © 2016年 yangkejun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LocalSection : UITableViewController

@property (nonatomic, assign) NSInteger localSection;

@end
