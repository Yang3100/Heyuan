//
//  TotalViewController.h
//  XinMinClub
//
//  Created by Jason_zzzz on 16/3/25.
//  Copyright © 2016年 yangkejun. All rights reserved.
//

#import "WMPageController.h"

@interface TotalViewController  : WMPageController

@end
