//
//  TotalTableViewController.h
//  XinMinClub
//
//  Created by Jason_zzzz on 16/3/25.
//  Copyright © 2016年 yangkejun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TotalTableViewController : UITableViewController

@property (nonatomic, assign) NSInteger sectionNum;


@end
