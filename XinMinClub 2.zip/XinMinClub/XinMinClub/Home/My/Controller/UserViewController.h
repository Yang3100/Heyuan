//
//  UserViewController.h
//  XinMinClub
//
//  Created by Jason_zzzz on 16/3/22.
//  Copyright © 2016年 yangkejun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UserViewController : UIViewController

@property (nonatomic, strong) UITableView *userTableView;

@end
