//
//  UserFirstCell.m
//  XinMinClub
//
//  Created by Jason_zzzz on 16/3/22.
//  Copyright © 2016年 yangkejun. All rights reserved.
//

#import "UserFirstCell.h"

@implementation UserFirstCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
