//
//  HomeViewController.h
//  XinMinClub
//
//  Created by yangkejun on 16/3/19.
//  Copyright © 2016年 yangkejun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "WMPageController.h"

@interface HomeViewController : WMPageController


@end
