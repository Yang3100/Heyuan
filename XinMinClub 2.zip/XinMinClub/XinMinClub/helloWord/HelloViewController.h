//
//  HelloViewController.h
//  LoginSection
//
//  Created by 杨科军 on 2016/12/15.
//  Copyright © 2016年 杨科军. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HelloViewController : UIViewController

- (void)ADImage:(UIImage*)adim waitingTime:(NSTimeInterval)time;

@end
