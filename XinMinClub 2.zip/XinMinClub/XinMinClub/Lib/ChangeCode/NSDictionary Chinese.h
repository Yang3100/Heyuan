//
//  NSDictionary+Chinese.h
//  ObjCDemo
//
//  Created by Dragon Sun on 15/12/11.
//  Copyright © 2015年 Dragon Sun. All rights reserved.
//
//  解决使用NSLog()打印乱码的问题
//

#import <Foundation/Foundation.h>

@interface NSDictionary (Chinese)

@end
