//
//  ProvinceAddressModel.m
//  picker
//
//  Created by 王帅 on 14/11/22.
//  Copyright (c) 2014年 Sylar. All rights reserved.
//

#import "ProvinceAddressModel.h"

@implementation ProvinceAddressModel


//- (void)setValue:(id)value forUndefinedKey:(NSString *)key
//{
//    
//    if ([key isEqualToString:@"id"]) {
//        [self setValue:value forKey:@"ID"];
//    }
//    
//}

@end
