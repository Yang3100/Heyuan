//
//  DistrictModel.m
//  picker
//
//  Created by 王帅 on 14/11/22.
//  Copyright (c) 2014年 Sylar. All rights reserved.
//

#import "DistrictModel.h"

@implementation DistrictModel

@end
