//
//  RegisterViewController.h
//  XinMinClub
//
//  Created by yangkejun on 16/3/18.
//  Copyright © 2016年 yangkejun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SubmitViewController : UIViewController

@property(nonatomic, copy) NSString *iphoneNum;
@property (nonatomic, copy) NSString *country;

@end
