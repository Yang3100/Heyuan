//
//  ForgetViewController.h
//  XinMinClub
//
//  Created by yangkejun on 16/3/19.
//  Copyright © 2016年 yangkejun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ForgetViewController : UIViewController

@property (nonatomic, copy) NSString *iphoneNum;

@end
